import si from 'systeminformation'

console.log((await si.mem()))