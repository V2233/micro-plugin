import{ad as t}from"./index-683eb2c7.js";const e=s=>t.get("/bot/logs?id="+s),o=()=>t.get("/bot/status");export{e as a,o as r};
