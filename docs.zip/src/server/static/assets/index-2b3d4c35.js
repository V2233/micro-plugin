import{a as _,_ as e}from"./index-85ec3edf.js";const n=_({__name:"index",setup(t){return(a,s)=>null}});const c=e(n,[["__scopeId","data-v-a7bb3022"]]);export{c as default};
