import{a as _,_ as e}from"./index-85ec3edf.js";const n=_({__name:"index",setup(t){return(a,s)=>null}});const c=e(n,[["__scopeId","data-v-68223ab6"]]);export{c as default};
