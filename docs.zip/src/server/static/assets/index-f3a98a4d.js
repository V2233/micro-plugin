import{ad as t}from"./index-de339125.js";const e=s=>t.get("/bot/logs?id="+s),o=()=>t.get("/bot/status");export{e as a,o as r};
