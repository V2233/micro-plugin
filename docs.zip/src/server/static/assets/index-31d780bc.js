import{a as e}from"./index-a06f622c.js";const a=e({__name:"index",setup(n){return(t,r)=>null}});export{a as default};
