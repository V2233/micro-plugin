import{a as e}from"./index-85ec3edf.js";const a=e({__name:"index",setup(n){return(t,r)=>null}});export{a as default};
