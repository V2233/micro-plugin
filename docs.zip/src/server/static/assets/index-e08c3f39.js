import{a7 as t}from"./index-ba90849c.js";const e=s=>t.get("/bot/logs?id="+s),o=()=>t.get("/bot/status");export{e as a,o as r};
