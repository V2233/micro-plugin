import{a6 as t}from"./index-a06f622c.js";const e=s=>t.get("/logs?id="+s),o=()=>t.get("/status");export{e as a,o as r};
