import type { EventType } from './types.ts';
export declare function handleNoticeGroupPoke(e: EventType): Promise<void>;
