export declare const botInfo: {
    WORK_PATH: string;
    BOT_NAME: string;
    BOT_VERSION: string;
    BOT_DESC: string;
    BOT_AUTHOR: string;
};
