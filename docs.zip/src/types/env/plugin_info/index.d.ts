export declare const pluginInfo: {
    ROOT_PATH: string;
    ROOT_NAME: string;
    PLUGIN_NAME: string;
    PLUGIN_VERSION: string;
    PLUGIN_DESC: string;
    PLUGIN_AUTHOR: string;
};
