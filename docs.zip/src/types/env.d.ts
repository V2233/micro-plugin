export declare const pluginInfo: {
    ROOT_PATH: string;
    ROOT_NAME: string;
    PLUGIN_NAME: string;
    PLUGIN_VERSION: string;
    PLUGIN_DESC: string;
    PLUGIN_AUTHOR: string;
};
export declare const botInfo: {
    WORK_PATH: string;
    BOT_NAME: string;
    BOT_VERSION: string;
    BOT_DESC: string;
    BOT_AUTHOR: string;
};
