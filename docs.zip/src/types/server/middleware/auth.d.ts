declare const auth: (ctx: any, next: any) => Promise<any>;
export default auth;
