declare class StateController {
    sysInfo(ctx: any): Promise<void>;
}
declare const _default: StateController;
export default _default;
