export default function getSwapInfo(): Promise<{
    inner: string;
    percentage: number;
    title: string;
    info: string[];
}>;
