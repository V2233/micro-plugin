export declare let si: any;
export declare let osInfo: any;
export declare let colorthief: any;
export declare function initDependence(): Promise<any>;
export declare function getFileSize(size: any, { decimalPlaces, showByte, showSuffix }?: {
    decimalPlaces?: number;
    showByte?: boolean;
    showSuffix?: boolean;
}): string;
