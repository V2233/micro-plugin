export default function getNetwork(): Promise<any>;
