export declare function getFsSize(): Promise<any>;
export declare function getDiskSpeed(): false | {
    rx_sec: string;
    wx_sec: string;
};
