export default function getFastFetch(): Promise<any>;
