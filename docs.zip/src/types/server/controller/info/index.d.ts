declare class InfoController {
    botInfo(ctx: any): Promise<void>;
    botURI(ctx: any): Promise<void>;
}
declare const _default: InfoController;
export default _default;
