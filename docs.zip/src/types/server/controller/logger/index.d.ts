declare class LogController {
    logger(ctx: any): Promise<void>;
}
declare const _default: LogController;
export default _default;
