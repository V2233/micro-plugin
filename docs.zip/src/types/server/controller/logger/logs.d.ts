export declare function getLatestLog(logs: string[]): string;
