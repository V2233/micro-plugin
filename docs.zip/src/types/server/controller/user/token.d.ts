export declare function createToken(payload: any, skey: any): any;
