export declare function customizer(objValue: any, srcValue: any): any;
