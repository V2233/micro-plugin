import Router from 'koa-router';
declare const router: Router<any, {}>;
export default router;
