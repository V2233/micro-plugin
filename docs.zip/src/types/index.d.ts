declare const _default: () => import("yunzai").ApplicationOptions;
export default _default;
