import type { EventType } from './types.ts'
export async function handleNoticeGroupPoke(e: EventType) {
    console.log(e)
}