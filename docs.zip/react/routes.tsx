// import React from "react"
// import { type RouterType } from "./types.ts"
// import Hello from "../apps/test/hello.tsx"

// const Config: RouterType = [
//   {
//     url: "/",
//     element: <Hello data={{ name: "word" }} />
//   }
// ]
// export default Config