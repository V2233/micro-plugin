// import { type ComponentCreateOpsionType } from 'yunzai/utils'
// export type RouterType = {
//   url: string
//   element: React.ReactNode
//   options?: ComponentCreateOpsionType
// }[]
